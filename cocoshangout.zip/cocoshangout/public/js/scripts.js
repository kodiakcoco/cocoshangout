// scripts.js

document.addEventListener('DOMContentLoaded', () => {
    const socket = io(); // Connect to the server
    const messageInput = document.querySelector('.message-input input');
    const sendButton = document.querySelector('.message-input button');
    const chatWindow = document.querySelector('.chat-window');
    const createPortalForm = document.getElementById('create-portal-form');
    const portalUsernameInput = document.getElementById('portal-username');
    const channelList = document.getElementById('channel-list');
    const currentChannelHeader = document.getElementById('current-channel');

    // Retrieve username from local storage
    const username = localStorage.getItem('username');
    
    if (!username) {
        window.location.href = 'login.html'; // Redirect to login if no username is set
    }

    // Function to add a message to the chat window
    function addMessage(message, sender) {
        const messageElement = document.createElement('div');
        messageElement.className = 'message';
        messageElement.textContent = `${sender}: ${message}`;
        chatWindow.appendChild(messageElement);
        chatWindow.scrollTop = chatWindow.scrollHeight; // Scroll to bottom
    }

    // Handle the send button click event
    sendButton.addEventListener('click', () => {
        const message = messageInput.value.trim();
        if (message) {
            const currentChannel = currentChannelHeader.textContent;
            socket.emit('chat message', { username, message, channel: currentChannel }); // Send message with username to server
            messageInput.value = ''; // Clear input field
        }
    });

    // Handle 'Enter' key press for sending messages
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            sendButton.click();
        }
    });

    // Listen for 'chat message' events from the server
    socket.on('chat message', ({ username, message, channel }) => {
        if (channel === currentChannelHeader.textContent) {
            console.log('Message received on client:', { username, message }); // Debugging line
            addMessage(message, username); // Display message with sender's username
        }
    });

    // Handle create portal form submission
    createPortalForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const portalUsername = portalUsernameInput.value.trim();

        if (portalUsername) {
            fetch('/create-portal', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ portalUsername })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Add new portal to the channel list
                    const li = document.createElement('li');
                    const a = document.createElement('a');
                    a.href = "#";
                    a.textContent = data.portalName;
                    a.setAttribute('data-channel', data.portalName);
                    a.addEventListener('click', (event) => {
                        event.preventDefault();
                        currentChannelHeader.textContent = data.portalName;
                        chatWindow.innerHTML = ''; // Clear chat window for new channel
                    });
                    li.appendChild(a);
                    channelList.appendChild(li);
                    portalUsernameInput.value = ''; // Clear the input field
                } else {
                    alert('Error creating portal: ' + data.message);
                }
            });
        }
    });

    // Handle channel switching
    document.querySelectorAll('#channel-list a').forEach(channelLink => {
        channelLink.addEventListener('click', (event) => {
            event.preventDefault();
            const channelName = channelLink.getAttribute('data-channel');
            currentChannelHeader.textContent = channelName;
            chatWindow.innerHTML = ''; // Clear chat window for new channel
        });
    });
});
