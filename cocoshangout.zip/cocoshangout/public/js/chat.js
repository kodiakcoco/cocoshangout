// chat.js

document.addEventListener('DOMContentLoaded', () => {
    const usernameDisplay = document.getElementById('username-display');
    const username = localStorage.getItem('username');

    // Redirect to login if no username is set
    if (!username) {
        window.location.href = 'login.html';
    } else {
        usernameDisplay.textContent = `Logged in as: ${username}`;
    }

    // Clear username from local storage on page unload
    window.addEventListener('beforeunload', () => {
        localStorage.removeItem('username');
    });
});
