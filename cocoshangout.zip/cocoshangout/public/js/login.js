// login.js

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('login-form');
    const usernameInput = document.getElementById('username');

    // Check if username is already saved
    if (localStorage.getItem('username')) {
        window.location.href = 'chat.html'; // Redirect to chat if already logged in
    }

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const username = usernameInput.value.trim();
        if (username) {
            localStorage.setItem('username', username); // Save username to local storage
            window.location.href = 'chat.html'; // Redirect to chat page
        }
    });
});
