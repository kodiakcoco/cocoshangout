// server.js

const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const fs = require('fs');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

app.use(express.json());

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Serve HTML files from the 'views' directory
app.use('/', express.static(path.join(__dirname, 'views')));

// Paths to JSON files in the 'data' directory
const channelsPath = path.join(__dirname, 'data', 'channels.json');
const portalsPath = path.join(__dirname, 'data', 'portals.json');

// Endpoint to get channels
app.get('/channels', (req, res) => {
    fs.readFile(channelsPath, 'utf8', (err, data) => {
        if (err) {
            res.status(500).send('Error reading channels');
            return;
        }
        res.json(JSON.parse(data));
    });
});

// Endpoint to create a private portal
app.post('/create-portal', (req, res) => {
    const { portalUsername } = req.body;
    const portalName = `Private Portal with ${portalUsername}`;

    fs.readFile(portalsPath, 'utf8', (err, data) => {
        if (err) {
            res.status(500).send('Error reading portals');
            return;
        }

        const portals = JSON.parse(data);
        portals.portals.push(portalName);

        fs.writeFile(portalsPath, JSON.stringify(portals, null, 2), 'utf8', (err) => {
            if (err) {
                res.status(500).send('Error writing portals');
                return;
            }
            res.json({ success: true, portalName });
        });
    });
});

// Handle Socket.IO connections
io.on('connection', (socket) => {
    console.log('A user connected');

    // Listen for 'chat message' events from clients
    socket.on('chat message', ({ username, message, channel }) => {
        console.log(`Message from ${username} in ${channel}: ${message}`); // Debugging line
        io.emit('chat message', { username, message, channel }); // Broadcast message with username and channel
    });

    // Handle disconnection
    socket.on('disconnect', () => {
        console.log('User disconnected');
    });
});

// Start the server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
